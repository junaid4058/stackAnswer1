//
//  CustomViewClass.m
//  stackAnswer
//
//  Created by Junaid's Mac Mini  on 4/24/17.
//  Copyright © 2017 Cuet. All rights reserved.
//

#import "CustomViewClass.h"


@implementation CustomViewClass

+ (UIView*)makeCustomViewWithBottomConstraint:(NSInteger)bottomConstant andHeight:(NSInteger)viewHeight inViewController:(UIViewController*)vc{
    
    UIView *customView = [[UIView alloc]init];
    [vc.view addSubview:customView];
    customView.backgroundColor = [UIColor purpleColor];
    customView.translatesAutoresizingMaskIntoConstraints = NO;
    
    NSDictionary *metrics = @{@"viewHeight":@(viewHeight),
                              @"bottomConstant":@(bottomConstant)};
    NSDictionary *views = NSDictionaryOfVariableBindings(customView);
    
    NSArray *hConstraint = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|[customView]|"
                                                                              options:0
                                                                              metrics:metrics
                                                                                views:views];
    NSArray *vConstraint = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[customView(viewHeight)]-bottomConstant-|"
                                                                              options:0
                                                                              metrics:metrics
                                                                                views:views];
    


    [vc.view addConstraints:hConstraint];
    [vc.view addConstraints:vConstraint];
    
    return customView;
    
}

//Get top most View controller
+ (UIViewController*)getTopViewController {
        UIViewController *topController = [UIApplication sharedApplication].keyWindow.rootViewController;
        
        while (topController.presentedViewController) {
            topController = topController.presentedViewController;
        }
        
        return topController;

}

@end
