//
//  AppDelegate.h
//  stackAnswer
//
//  Created by Junaid's Mac Mini  on 4/24/17.
//  Copyright © 2017 Cuet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

