//
//  CustomViewClass.h
//  stackAnswer
//
//  Created by Junaid's Mac Mini  on 4/24/17.
//  Copyright © 2017 Cuet. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface CustomViewClass : NSObject

+ (UIView*)makeCustomViewWithBottomConstraint:(NSInteger)bottomConstant andHeight:(NSInteger)viewHeight inViewController:(UIViewController*)vc ;
+ (UIViewController*)getTopViewController;
@end
